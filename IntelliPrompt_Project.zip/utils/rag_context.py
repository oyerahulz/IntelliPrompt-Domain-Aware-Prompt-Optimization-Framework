
def fetch_context(query: str):
    import pinecone, openai
    # Simulate semantic search + context retrieval (mocked here)
    return "Relevant context based on: " + query
