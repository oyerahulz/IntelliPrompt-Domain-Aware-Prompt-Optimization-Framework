
import streamlit as st
import openai

st.title("IntelliPrompt Playground")

openai.api_key = st.text_input("Enter your OpenAI API Key:", type="password")

prompt = st.text_area("Enter your prompt here:")

if st.button("Generate Response"):
    if openai.api_key and prompt:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ]
        )
        st.write(response['choices'][0]['message']['content'])
    else:
        st.warning("Please provide both a prompt and API key.")
